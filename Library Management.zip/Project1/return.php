<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<link rel="icon" href="logo.png">
     <title>Return Book</title>
	 <style>
	 .row
     {
	 margin-top:10px;
	 }
	 </style>
  </head>
    <body>
	<div class="container">
	
	<div class="row">
	   <div class="col-sm-7" id="main_logo">
	    <img src="image/cdlul.jpg"  alt="Vivekanand Library" class="img-fluid" title="Vivekanand Library">
	   </div>
	   <div class="col-sm-5" style="margin-top:22px;">
	    <h4>Welcome To Vivekanand Library</h4>
	     <div class="row" style="margin-top:4px;">
		    <div class="col-sm-8" margin-top:2px;>
			 <button onclick="history.back();" class="btn btn-info" style="cursor:pointer" title="Back" accesskey="k">
			 <img src="image/arrow-l-white.png">
			 </button>
			 <button onclick="window.location.reload();" class="btn btn-danger" style="cursor:pointer" title="refresh" accesskey="h">
			 <img src="image/refresh-white.png">
			 </button>
			 <button class="btn btn-primary" style="cursor:pointer" title="About Us." accesskey="A">
			 <img src="image/info-white.png">
			  </button>
			 
			</div>
		   </div>
		</div>
	   </div>
	  
	  <center>
	      <h2 style="margin-top:5px;">Return Book</h2>
	  </center>
	  <form action="return.php" method="post">
	   <div class="row" style="background:#e6e6e6;">
	      <div class="col-sm-3">
		  <a href="Search.php">
		  <img src="images/search.jpg" class="img-fluid" width="100" height="auto" style="margin-left:6px;margin-top:8px;margin-bottom:8px">
		  </a>
		  </div>
		   <div class="col=sm-7">
		    <div class="input-group">
		    <select class="form-control" name="search" style="width:auto; margin-top:16px;margin-bottom:8px;"autofocus>
			<option></option>
			<?php
           $mydb= new mysqli("localhost","root","","search");
           $sql="SELECT * FROM student ORDER BY m_no";
           $result=$mydb->query($sql);
           
 		   while($row=$result->fetch_assoc())
		   {
			   echo"<option>".$row['m_no']."</option>";
		   }
			?>
			</select>
			<span class="input-group-btn">
			<input type="submit" class="btn btn-secondary" name="searchb" value="Search"style="margin-top:16px;margin-bottom:8px">
			</span>
		    </div>
		   </div>		    
	   </div>
	  </form>
	 </div>
	 
	 <?php
	 $mydb=new mysqli("localhost","root","","search");
	
	 if(isset($_POST["searchb"]))
	 {  
          $search=$_POST['search'];
	    if($search=="")
		{
			echo "<center><b>Sorry!!!...Please Give Me Some Inputs....... </b></center>";
			exit();
		}
	 
	 
	$sql="SELECT * FROM issue WHERE m_no LIKE '$search' ";
    $result=$mydb->query($sql);
		
	 
echo "<center><div class='table-responsive'>
<table border='' style='font-weight:bold;margin:20px;' 'class='table-striped' >
<br><tr style='background:gold;'>
<th>Sr. No.</th><th >Book Id</th><th >Book Name</th><th>Membership No.</th><th>Due Date</th><th></th></tr>";
$a=1;
while($row=$result->fetch_assoc())
{
			echo "<tr><td>".$a."</td><td>".$row['bid']."
			</td><td>".$row['bname']."</td><td>".$row['m_no']."</td><td>".$row['dd']."</td><td>
			<form action='return.php' method='post'/>
			<input type='hidden' value='$row[id]' name='id'/>
			<input type='submit' name='return' class='btn btn-danger' value='Return Book' style='cursor:pointer'/>
			</form>
			</td>
			</tr>";
             $a++;
}
	 }
	 if(isset($_POST["return"]))
	{ 
	 $id=$_POST['id'];
	 $sql1="DELETE FROM issue WHERE id LIKE '$id'";
	 $result=$mydb->query($sql1);
	 if($result==TRUE)
	 {

		echo"<script>alert('Return Book Successfully!!!')</script>";
      		
	 }
	 else
	 {
		 echo"<script>alert('Oops Error!!!')</script>"; 
	 }
	}
	 
?>
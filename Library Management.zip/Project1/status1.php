<!DOCTYPE html>
<html lang="en">
  <head>
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<link rel="icon" href="logo.png">
     <title>status</title>
	 <style>
	 input[type='text']
	 {
		font-weight:bold;
		font-size:20px;
	 } 
	 .row
     {
	 margin-top:10px;
	 }
	 </style>
  </head>
    <body>
	<div class="container">
	
	<div class="row">
	   <div class="col-sm-7" id="main_logo">
	    <img src="image/cdlul.jpg"  alt="Vivekanand Library" class="img-fluid" title="Vivekanand Library">
	   </div>
	   <div class="col-sm-5" style="margin-top:22px;">
	    <h4>Welcome To Vivekanand Library</h4>
	     <div class="row" style="margin-top:4px;">
		    <div class="col-sm-8" margin-top:2px;>
			 <button onclick="history.back();" class="btn btn-info" style="cursor:pointer" title="Back" accesskey="k">
			 <img src="image/arrow-l-white.png">
			 </button>
			 <button onclick="window.location.reload();" class="btn btn-danger" style="cursor:pointer" title="refresh" accesskey="h">
			 <img src="image/refresh-white.png">
			 </button>
			 <button class="btn btn-primary" style="cursor:pointer" title="About Us." accesskey="A">
			 <img src="image/info-white.png">
			  </button>
			 
			</div>
		   </div>
		</div>
	   </div>
	  
	  <center>
	  	      <h2 style="margin-top:5px;">Check Status</h2>
		  	  </center>
	  <?php
	 $mydb=new mysqli("localhost","root","","search");
	 $id=$_POST['id'];
	 $sql="SELECT * FROM book where id like '$id'";
	 $sql1="SELECT * FROM issue where bid like '$id'";
     
	 $result=$mydb->query($sql);
	 $row=$result->fetch_assoc();
	 $result1=$mydb->query($sql1);
	 $row1=$result1->fetch_assoc();
	 
	 echo"<form action='status1.php' method='post' enctype='multipart/form-data'>
       	    <div class='form-group'>
			<div class='row'>
	    <label for='id' class='col-sm-2'><b>Book <u>i</u>d:</b></label>
		<div class='col-sm-10'>
		<input type='text' class='form-control' name='id' id='id' value='$row[id]' accesskey='I' required disabled>
	   	      </div>
	     </div>
		 <div class='row'>
	    <label for='bname' class='col-sm-2'><b><u>B</u>ook Name:</b></label>
		<div class='col-sm-10'>
		<input type='text' class='form-control' name='bname' id='bname' value='$row[name]' placeholder='Enter Book Name' accesskey='B'  required disabled>
	   	      </div>
	     </div>
		 <div class='row'>
	    <label for='author' class='col-sm-2'><b><u>A</u>uthor:</b></label>
		<div class='col-sm-10'>
		<input type='text' class='form-control' name='author' id='author' value='$row[author]' accesskey='a' required disabled>
	   	      </div>
	     </div>
		 <div class='row'>
	    <label for='publisher' class='col-sm-2'><b><u>P</u>ublisher:</b></label>
		<div class='col-sm-10'>
		<input type='text' class='form-control' name='publisher' id='publisher' value='$row[publisher]' accesskey='P' required disabled>
	   	      </div>
	     </div>
		 
		 </div></form>";
		 
		 if($row['id']==$row1['bid'])
		 {
			 echo "<center><b><font color='red' size='18'>Book Issued</font></b></center><br>";
			 $mno=$row1['m_no'];
	 		 $sql2="SELECT * FROM student where m_no like '$mno'";	 
	         $result2=$mydb->query($sql2);
	         $row2=$result2->fetch_assoc();
			 echo "<center><h5>Issue Information About Book See From Below Table</h5></center>";
			 echo "<center><div class='table-rsponsive'>
             <table border='' style='font-weight:bold; 'class='table-striped'>
             <br><tr style='background:gold;'>
             <th>Menbership No.</th><th >Name</th><th>Class</th><th>Roll No.</th><th>Department</th><th>Mobile No.</th><th>Due Date</th><th></th></tr>";
			 echo "<tr><td>".$row2['m_no']."</td><td>".$row2['name']."</td><td>".$row2['class']."</td>
			 <td>".$row2['roll']."</td><td>".$row2['department']."</td><td>".$row2['mobile']."</td><td>".$row1['dd']."</td><td><image src='images/".$row2['image']."' class='img-fluid' width='50'></td></tr>";
             
			 echo"</tr></table><br><button type='button' class='btn btn-danger' accesskey='P' onclick='window.print()'>Print</button>";
		 }
		 else
		 {
			  echo "<center><b><font color='Green' size='18'>Book Not issued</font></b></center>";
		 }
	?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<link rel="icon" href="logo.png">
     <title>Insert Book</title>
	 <style>
	 .row
     {
	 margin-top:10px;
	 }
	 </style>
  </head>
    <body>
	<div class="container">
	
	<div class="row">
	   <div class="col-sm-7" id="main_logo">
	    <img src="image/cdlul.jpg"  alt="Vivekanand Library" class="img-fluid" title="Vivekanand Library">
	   </div>
	   <div class="col-sm-5" style="margin-top:22px;">
	    <h4>Welcome To Vivekanand Library</h4>
	     <div class="row" style="margin-top:4px;">
		    <div class="col-sm-8" margin-top:2px;>
			 <button onclick="history.back();" class="btn btn-info" style="cursor:pointer" title="Back" accesskey="k">
			 <img src="image/arrow-l-white.png">
			 </button>
			 <button onclick="window.location.reload();" class="btn btn-danger" style="cursor:pointer" title="refresh" accesskey="h">
			 <img src="image/refresh-white.png">
			 </button>
			 <button class="btn btn-primary" style="cursor:pointer" title="About Us." accesskey="A">
			 <img src="image/info-white.png">
			  </button>
			 
			</div>
		   </div>
		</div>
	   </div>
	  
	  <center>
	      <h2 style="margin-top:5px;">Insert Book</h2>
	  </center>
	    <form action="add_book.php" method="post" enctype="multipart/form-data">
	    <div class="form-group">
		 <div class="row">
	    <label for="bname" class="col-sm-2"><b><u>B</u>ook Name:</b></label>
		<div class="col-sm-10">
		<input type="text" class="form-control" name="bname" id="bname" placeholder="Enter Book Name" accesskey="B" autofocus required>
	   	      </div>
	     </div>
		 <div class="row">
	    <label for="aname" class="col-sm-2"><b><u>A</u>uthor Name:</b></label>
		<div class="col-sm-10">
		<input type="text" class="form-control" name="aname" id="aname" placeholder="Enter Book's Author Name" accesskey="A" required>
	   	      </div>
	     </div>
		 <div class="row">
	    <label for="pname" class="col-sm-2"><b><u>P</u>ublisher Name:</b></label>
		<div class="col-sm-10">
		<input type="text" class="form-control" name="pname" accesskey="P" id="pname" placeholder="Enter Book's Publisher Name"required>
	   	      </div>
	     </div>
		 <div class="row">
	    <label for="detail" class="col-sm-2"><b>Descriptio<u>n</u>:</b></label>
		<div class="col-sm-10">
		<textarea class="form-control" name="detail" id="detail" value="" placeholder="Enter Book Description" accesskey="n" required>
		</textarea>
	   	      </div>
	     </div>
		 <div class="row">
	    <label for="image" class="col-sm-2"><b><u>I</u>nsert image:</b></label>
		<div class="col-sm-10">
		<input type="file" class="form-control" name="image" id="image" accesskey="I" required>
	   	      </div>
	     </div>
		 <br>
		 <div class="row">
	      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input type="submit" class="btn btn-success" name="submit" id="submit" accesskey="S" value="Add Record" style="cursor:pointer">
		&nbsp;&nbsp;
		   	 <input type="reset" class="btn btn-primary" name="reset" id="reset" value="Reset Form" accesskey="R"style=" cursor:pointer">  
		 
		 </div>
             		 
	    </div>
	   </form>
	</div>
	
	
	
	</body>
	<?php
	mysql_connect("localhost","root","");
	mysql_select_db("search");
	if(isset($_POST["submit"]))
	{ 
      echo $bname=addslashes($_POST["bname"]);
	  echo $aname=addslashes($_POST["aname"]);
	  echo $pname=addslashes($_POST["pname"]);
	  echo $detail=addslashes($_POST["detail"]);
	  echo $image=addslashes($_FILES["image"]["name"]);
	   if(move_uploaded_file($_FILES["image"]["tmp_name"],"images/".$_FILES["image"]["name"])) 
	  {
		  $sql="INSERT INTO book(name,author,publisher,description,image)VALUES('$bname','$aname','$pname','$detail','$image')";
	  $query=mysql_query($sql);
	   if($query)
	   {
		   echo "<script>alert('Add Book Successfully!!!')</script>";
	   }
	    else
		{
			echo "<script>alert('Error,Try Again!!!')</script>";
		}
	  }
	}	
	?>
	 
	 
</html>
	 
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<link rel="icon" href="logo.png">
     <title>Add Student Info.</title>
	 <style>
	 .row
     {
	 margin-top:10px;
	 }
	 </style>
  </head>
    <body>
	<div class="container">
	
	<div class="row">
	   <div class="col-sm-7" id="main_logo">
	    <img src="image/cdlul.jpg"  alt="Vivekanand Library" class="img-fluid" title="Vivekanand Library">
	   </div>
	   <div class="col-sm-5" style="margin-top:22px;">
	    <h4>Welcome To Vivekanand Library</h4>
	     <div class="row" style="margin-top:4px;">
		    <div class="col-sm-8" margin-top:2px;>
			 <button onclick="history.back();" class="btn btn-info" style="cursor:pointer" title="Back" accesskey="k">
			 <img src="image/arrow-l-white.png">
			 </button>
			 <button onclick="window.location.reload();" class="btn btn-danger" style="cursor:pointer" title="refresh" accesskey="h">
			 <img src="image/refresh-white.png">
			 </button>
			 <button class="btn btn-primary" style="cursor:pointer" title="About Us." accesskey="A">
			 <img src="image/info-white.png">
			  </button>
			 
			</div>
		   </div>
		</div>
	   </div>
	  
	  <center>
	      <h2 style="margin-top:5px;">Add Student Info.</h2>
	  </center>
	    <form action="add_student.php" method="post" enctype="multipart/form-data">
		<div class="form-group">
		 <div class="row">
	    <label for="mno" class="col-sm-2"><b><u>M</u>embership No.:</b></label>
		<div class="col-sm-10">
		<input type="text" class="form-control" name="mno" id="mno" placeholder="Enter Membership No." accesskey="m" autofocus required>
	   	      </div>
	     </div>
		 <div class="row">
	    <label for="name" class="col-sm-2"><b><u>N</u>ame:</b></label>
		<div class="col-sm-10">
		<input type="text" class="form-control" name="name" id="name" placeholder="Enter Student Name" accesskey="n" required>
	   	      </div>
	     </div>
		 <div class="row">
	    <label for="class" class="col-sm-2"><b><u>C</u>lass:</b></label>
		<div class="col-sm-10">
		<input type="text" class="form-control" name="class" accesskey="c" id="pname" placeholder="Enter Class Name" required>
	   	      </div>
	     </div>
		 
		 <div class="row">
	    <label for="roll" class="col-sm-2"><b>R<u>o</u>ll No.:</b></label>
		<div class="col-sm-10">
		<input type="tel" class="form-control" name="roll" accesskey="O" id="roll" placeholder="Enter Roll No." required>
	   	      </div>
	     </div>
		 <div class="row">
	    <label for="Department" class="col-sm-2"><b>De<u>p</u>artment:</b></label>
		<div class="col-sm-10">
		<input type="text" class="form-control" name="Department" accesskey="P" id="Department" placeholder="Enter Department Name" required>
	   	      </div>
	     </div>
		 
		 <div class="row">
	    <label for="mobile" class="col-sm-2"><b><u>M</u>obile No.:</b></label>
		<div class="col-sm-10">
		<input type="tel" class="form-control" name="mobile" accesskey="M" id="mobile" placeholder="Enter Mobile No." required>
	   	      </div>
	     </div>
		 
		 <div class="row">
	    <label for="image" class="col-sm-2"><b><u>I</u>nsert image:</b></label>
		<div class="col-sm-10">
		<input type="file" class="form-control" name="image" id="image" accesskey="I" required>
	   	      </div>
	     </div>
		 <br>
		 <div class="row">
	      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input type="submit" class="btn btn-success" name="submit" id="submit" accesskey="S" value="Add Record" style="cursor:pointer">
		&nbsp;&nbsp;
		   	 <input type="reset" class="btn btn-primary" name="reset" id="reset" value="Reset Form" accesskey="R"style=" cursor:pointer">  
		 
		 </div>
             		 
	    </div>
	   </form>
	</div>
	
	</body>
	<?php
	$mydb= new mysqli("localhost","root","","search");
	if(isset($_POST["submit"]))
	{ 
      echo "<b>Your Last Entry: </b>";
      echo $mno=addslashes($_POST["mno"]);
	  echo "&nbsp;";
	  echo $name=addslashes($_POST["name"]);
	  echo "&nbsp;";
	  echo $class=addslashes($_POST["class"]);
	  echo "&nbsp;";
	  echo $roll=addslashes($_POST["roll"]);
	  echo "&nbsp;";
	  echo $department=addslashes($_POST["Department"]);
	  echo "&nbsp;";
	  echo $mobile=addslashes($_POST["mobile"]);
	  echo "&nbsp;";
	  echo $image=addslashes($_FILES["image"]["name"]);
	  echo "&nbsp";
	   if(move_uploaded_file($_FILES["image"]["tmp_name"],"images/".$_FILES["image"]["name"])) 
	  {
		  $sql="INSERT INTO student(m_no,name,class,roll,department,mobile,image)VALUES('$mno','$name','$class','$roll','$department','$mobile','$image')";
	  
	   if($mydb->query($sql)==TRUE)
	   {
		   echo "<script>alert('Add Record Successfully!!!')</script>";
	   }
	    else
		{
			echo "<script>alert('Error,Try Again!!!')</script>";
		}
	  }
	}	
	?>
	 
</html>

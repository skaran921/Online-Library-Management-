<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<link rel="icon" href="logo.png">
     <title>View Books</title>
	 <style>
	 .row
     {
	 margin-top:10px;
	 }
	 </style>
  </head>
    <body>
	<div class="container">
	
	<div class="row">
	   <div class="col-sm-7" id="main_logo">
	    <img src="image/cdlul.jpg"  alt="Vivekanand Library" class="img-fluid" title="Vivekanand Library">
	   </div>
	   <div class="col-sm-5" style="margin-top:22px;">
	    <h4>Welcome To Vivekanand Library</h4>
	     <div class="row" style="margin-top:4px;">
		    <div class="col-sm-8" margin-top:2px;>
			 <button onclick="history.back();" class="btn btn-info" style="cursor:pointer" title="Back" accesskey="k">
			 <img src="image/arrow-l-white.png">
			 </button>
			 <button onclick="window.location.reload();" class="btn btn-danger" style="cursor:pointer" title="refresh" accesskey="h">
			 <img src="image/refresh-white.png">
			 </button>
			 <button class="btn btn-primary" style="cursor:pointer" title="About Us." accesskey="A">
			 <img src="image/info-white.png">
			  </button>
			 
			</div>
		   </div>
		</div>
	   </div>
	  
	  <center>
	      <h2 style="margin-top:5px;">Update Book</h2>
	  </center>
	  <?php
	 $mydb=new mysqli("localhost","root","","search");
	 $id=$_POST['id'];
	 $sql="SELECT * FROM book where id like '$id'";
	 $result=$mydb->query($sql);
	 $row=$result->fetch_assoc();
	 $description=$row['description'];
	 
echo"<form action='update2.php' method='post' enctype='multipart/form-data'>
       <input type='hidden' value='$id' name='id'>
	    <div class='form-group'>
		 <div class='row'>
	    <label for='bname' class='col-sm-2'><b><u>B</u>ook Name:</b></label>
		<div class='col-sm-10'>
		<input type='text' class='form-control' name='bname' id='bname' value='$row[name]' placeholder='Enter Book Name' accesskey='B' autofocus required>
	   	      </div>
	     </div>
		 <div class='row'>
	    <label for='aname' class='col-sm-2'><b><u>A</u>uthor Name:</b></label>
		<div class='col-sm-10'>
		<input type='text' class='form-control' name='aname' id='aname' value='$row[author]' placeholder='Enter Book's Author Name' accesskey='A' required>
	   	      </div>
	     </div>
		 <div class='row'>
	    <label for='pname' class='col-sm-2'><b><u>P</u>ublisher Name:</b></label>
		<div class='col-sm-10'>
		<input type='text' class='form-control' name='pname' accesskey='P' id='pname' value='$row[publisher]' placeholder='Enter Book's Publisher Name'required>
	   	      </div>
	     </div>
		 
	     
		 <br>
		 <div class='row'>
	      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<input type='submit' class='btn btn-success' name='submit' id='submit' accesskey='S' value='Update Record' style='cursor:pointer'>
		&nbsp;&nbsp;
		   	 <input type='reset' class='btn btn-primary' name='reset' id='reset' value='Reset Form' accesskey='R'style=' cursor:pointer'>  
		 
		 </div>
             		 
	    </div>
	   </form>
	</div>
	
	
	
	</body>";
?>
	
	 
</html>

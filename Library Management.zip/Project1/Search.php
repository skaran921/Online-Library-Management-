<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
 <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap-grid.css" rel="stylesheet">
	<link href="css/bootstrap-grid.min" rel="stylesheet">
	<link href="css/bootstrap-reboot" rel="stylesheet">
	<link href="css/bootstrap-reboot.min" rel="stylesheet">
	<link rel="icon" href="">

	
     <title>Home</title>
	 <style>
	 body
	 {
		 margin-top:6%;
	 }
	 </style>
	 <script>
	 function main()
	 {
		 document.searchbox.search.focus();
	 }
	 </script>
	 </head>
	 <body onload="main()">
	 <form name="searchbox" action="result.php" method="get">
	 <center>
	 <img src="images/search.jpg" alt="search" class="img-fluid" style="margin:2px;width:350px;">
	 <input type="search" class="form-control" name="search" style="width:60%; padding:10px;">
	 <input type="submit" name="searchb"class="btn btn-primary" value="Search"style="margin-top:8px;">
	 </center>
	 </body>
	 <script src="js/bootstrap.min.js"></script>
	 <script src="js/bootstrap.js"></script>
	 </html>
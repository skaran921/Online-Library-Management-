<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap-grid.css" rel="stylesheet">
	<link href="css/bootstrap-grid.min" rel="stylesheet">
	<link href="css/bootstrap-reboot" rel="stylesheet">
	<link href="css/bootstrap-reboot.min" rel="stylesheet">
	<link rel="icon" href="">
     <title>search result</title>
	 <style>
	 .result
	 {
		 margin-left:10%;margin-right:25%;margin:12px;
	 }
	 
	 </style>
  </head>
	 <body>
	 <div class="container-fluid">
	  <form action="result.php" method="get">
	   <div class="row" style="background:#e6e6e6;">
	      <div class="col-sm-3">
		  <a href="Search.php">
		  <img src="images/search.jpg" class="img-fluid" width="100" height="auto" style="margin-left:6px;margin-top:8px;margin-bottom:8px">
		  </a>
		  </div>
		   <div class="col=sm-7">
		    <div class="input-group">
		    <input type="search" class="form-control" name="search" style="width:auto; margin-top:16px;margin-bottom:8px;"autofocus>
			<span class="input-group-btn">
			<input type="submit" class="btn btn-secondary" name="searchb" value="Search"style="margin-top:16px;margin-bottom:8px">
			</span>
		    </div>
		   </div>		    
	   </div>
	  </form>
	 </div>
	 <div class="result">
	<table>
	 <tr>
	 <?php
	 $mydb= new mysqli("localhost","root","","search");
	 if(isset($_GET["searchb"]))
	 {
	    $search=$_GET["search"];
		if($search=="")
		{
			echo "<center><b>Sorry!!!...Please Give Me Some Inputs....... </b></center>";
			exit();
		}
		$sql="SELECT * FROM book WHERE name LIKE '%$search%' OR author LIKE '%$search%' OR publisher LIKE '%$search%' or description LIKE '%$search%' LIMIT 0,5";
		$result=$mydb->query($sql);
		/* if(mysql_num_rows($result)==NULL)
		{
			echo "<center><h4><b>Sorry!!! No Result Found.</b></h4></center>";
			exit();
		}
		*/
		echo"<hr>";
		echo "<font color='#0000ff'><b>Images For $search</b></font>";
		while($row=$result->fetch_assoc())
		{
			echo "<td><table><tr><td><img src='images/".$row['image']."' width='150px' height='150px'class='img-fluid'></td></tr></table></td> ";
			
		}
		
	 }
		 ?>
	 </tr>
	 </table>
	 <?php
	 echo "<a href='images.php?id=$search'> <font color='#lalaff'>More Image For $search</font></a><hr>";
	 $sql="SELECT * FROM book WHERE name LIKE '%$search%' OR author LIKE '%$search%' OR publisher LIKE '%$search%' or description LIKE '%$search%' ";
	 $result=$mydb->query($sql);
	 while($row=$result->fetch_assoc())
		{
			echo "<table><tr><td><font size='4' color='#0000cc'><b>".$row['name']."<b><br>";
			echo "<table><tr><td><font size='3' color='#006400'><b>".$row['author']."<b><br>";
			echo "<table><tr><td><font size='2' color='#008000'><b>Publisher:". $row['publisher']."<b><br>";
			echo "<table><tr><td><font size='1.8' color='#666666'><b>".$row['description']."<b><br>";
			echo "<hr>";
			
		}
	 
	 ?>
	 </body>
	 <script src="js/bootstrap.min.js"></script>
	 <script src="js/bootstrap.js"></script>
</html
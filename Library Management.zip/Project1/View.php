

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<link rel="icon" href="logo.png">
     <title>View Books</title>
	 <style>
	 .row
     {
	 margin-top:10px;
	 }
	 </style>
  </head>
    <body>
	<div class="container">
	
	<div class="row">
	   <div class="col-sm-7" id="main_logo">
	    <img src="image/cdlul.jpg"  alt="Vivekanand Library" class="img-fluid" title="Vivekanand Library">
	   </div>
	   <div class="col-sm-5" style="margin-top:22px;">
	    <h4>Welcome To Vivekanand Library</h4>
	     <div class="row" style="margin-top:4px;">
		    <div class="col-sm-8" margin-top:2px;>
			 <button onclick="history.back();" class="btn btn-info" style="cursor:pointer" title="Back" accesskey="k">
			 <img src="image/arrow-l-white.png">
			 </button>
			 <button onclick="window.location.reload();" class="btn btn-danger" style="cursor:pointer" title="refresh" accesskey="h">
			 <img src="image/refresh-white.png">
			 </button>
			 <button class="btn btn-primary" style="cursor:pointer" title="About Us." accesskey="A">
			 <img src="image/info-white.png">
			  </button>
			 
			</div>
		   </div>
		</div>
	   </div>
	  
	  <center>
	      <h2 style="margin-top:5px;">View Book</h2>
	  </center>
	  <?php
	 $mydb=new mysqli("localhost","root","","search");
	$sql="SELECT * FROM book order by name";
    $result=$mydb->query($sql);
		

echo "<center><div class='table-rsponsive'>
<table border='' style='font-weight:bold; 'class='table-striped'>
<br><tr style='background:gold;'>
<th>Sr. No.</th><th >Book Name</th><th>Author</th><th>Publisher</th><th>Image</th></tr>";
$a=1;
while($row=$result->fetch_assoc())
{
			echo "<tr><td>".$a."</td><td>".$row['name']."</td><td>".$row['author']."</td><td>".$row['publisher']."</td><td><image src='images/".$row['image']."' class='img-fluid' width='140px' height='auto'></td></tr>";
             $a++;
}
?>
</table>
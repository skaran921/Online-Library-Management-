<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<link href="css/bootstrap-grid.css" rel="stylesheet">
	<link href="css/bootstrap-grid.min" rel="stylesheet">
	<link href="css/bootstrap-reboot" rel="stylesheet">
	<link href="css/bootstrap-reboot.min" rel="stylesheet">
	<link rel="icon" href="">
     <title>images</title>
	 </head>
	 <body>
	 <div class="container-fluid">
	 <?php
	 $search=$_GET["id"];
	$mydb= new mysqli("localhost","root","","search");
	 $sql="SELECT * FROM book WHERE name LIKE '%$search%' OR author LIKE '%$search%' OR publisher LIKE '%$search%' or description LIKE '%$search%' ";
	$result=$mydb->query($sql);
	 while($row=$result->fetch_assoc())
		{
			echo "<img src='images/".$row['image']."' width='150' height='auto' class='img-fluid'> ";
			
		}
	 ?>
	 </body>
	 <script src="js/bootstrap.min.js"></script>
	 <script src="js/bootstrap.js"></script>
	 </html>
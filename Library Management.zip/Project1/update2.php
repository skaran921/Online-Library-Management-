<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<link rel="icon" href="logo.png">
     <title>View Books</title>
	 <style>
	 .row
     {
	 margin-top:10px;
	 }
	 </style>
  </head>
    <body>
	<div class="container">
	
	<div class="row">
	   <div class="col-sm-7" id="main_logo">
	    <img src="image/cdlul.jpg"  alt="Vivekanand Library" class="img-fluid" title="Vivekanand Library">
	   </div>
	   <div class="col-sm-5" style="margin-top:22px;">
	    <h4>Welcome To Vivekanand Library</h4>
	     <div class="row" style="margin-top:4px;">
		    <div class="col-sm-8" margin-top:2px;>
			 <button onclick="history.back();" class="btn btn-info" style="cursor:pointer" title="Back" accesskey="k">
			 <img src="image/arrow-l-white.png">
			 </button>
			 <button onclick="window.location.reload();" class="btn btn-danger" style="cursor:pointer" title="refresh" accesskey="h">
			 <img src="image/refresh-white.png">
			 </button>
			 <button class="btn btn-primary" style="cursor:pointer" title="About Us." accesskey="A">
			 <img src="image/info-white.png">
			 <a href="index.html"><button class="btn btn-Secoundary" style="cursor:pointer" title="Home" accesskey="H">
			 <img src="image/home-white.png">
			  </button></a>
			 
			</div>
		   </div>
		</div>
	   </div>
	  
	  <center>
	      <h2 style="margin-top:5px;">Update Book</h2>
	  </center>

<?php
	$mydb= new mysqli("localhost","root","","search");
	$id=$_POST["id"];
	if(isset($_POST["submit"]))
	{ 
      
       $bname=addslashes($_POST["bname"]);
	   $aname=addslashes($_POST["aname"]);
	   $pname=addslashes($_POST["pname"]);
	    $sql="UPDATE book SET name='$bname',author='$aname', publisher='$pname' WHERE id LIKE '$id'";
	  
	   if($mydb->query($sql)==TRUE)
	   {
		   echo "<script>alert('Update Book Successfully!!!')</script>";
		   echo "<b>Your Last Entry: </b><br>
	  <table style='font-weight:bold' border='1'class='table-striped'>
	  <tr style='background-color:black;color:#bc3'><td>Book Name</td><td>Author Name</td><td>Publisher Name</td></tr>";
	  echo "<tr><td>";
      echo $bname=addslashes($_POST["bname"]);
	  echo "</td><td>";
	  echo $aname=addslashes($_POST["aname"]);
	  
	   echo "</td><td>";
	  echo $pname=addslashes($_POST["pname"]);
	   echo"</td></tr></table>
	   <button type='button' class='btn btn-info' onclick='window.print();' style='margin-top:5px;cursor:pointer'>
	   <img src='image/b_print.png'>
	   Print
	   </button>";
	   }
	    else
		{
			echo "<script>alert('Error,Try Again!!!')</script>";
		}
	  
	}	
	?>
	
<!DOCTYPE html>
<html lang="en">
  <head>
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet">
	<script src="js/bootstrap.min.js"></script>
	<script src="js/bootstrap.js"></script>
	<link rel="icon" href="logo.png">
     <title>status</title>
	 <style>
	 .row
     {
	 margin-top:10px;
	 }
	 </style>
  </head>
    <body>
	<div class="container">
	
	<div class="row">
	   <div class="col-sm-7" id="main_logo">
	    <img src="image/cdlul.jpg"  alt="Vivekanand Library" class="img-fluid" title="Vivekanand Library">
	   </div>
	   <div class="col-sm-5" style="margin-top:22px;">
	    <h4>Welcome To Vivekanand Library</h4>
	     <div class="row" style="margin-top:4px;">
		    <div class="col-sm-8" margin-top:2px;>
			 <button onclick="history.back();" class="btn btn-info" style="cursor:pointer" title="Back" accesskey="k">
			 <img src="image/arrow-l-white.png">
			 </button>
			 <button onclick="window.location.reload();" class="btn btn-danger" style="cursor:pointer" title="refresh" accesskey="h">
			 <img src="image/refresh-white.png">
			 </button>
			 <button class="btn btn-primary" style="cursor:pointer" title="About Us." accesskey="A">
			 <img src="image/info-white.png">
			  </button>
			 
			</div>
		   </div>
		</div>
	   </div>
	  
	  <center>
	      <h2 style="margin-top:5px;">Check Status</h2>
		  	  </center>
	  <form action="status.php" method="post">
	   <div class="row" style="background:#e6e6e6;">
	      <div class="col-sm-3">
		  <a href="Search.php">
		  <img src="images/search.jpg" class="img-fluid" width="100" height="auto" style="margin-left:6px;margin-top:8px;margin-bottom:8px">
		  </a>
		  </div>
		   <div class="col=sm-7">
		    <div class="input-group">
		    <input type="search" class="form-control" name="search" style="width:auto; margin-top:16px;margin-bottom:8px;"autofocus>
			<span class="input-group-btn">
			<input type="submit" class="btn btn-secondary" name="searchb" value="Search"style="margin-top:16px;margin-bottom:8px">
			</span>
		    </div>
		   </div>		    
	   </div>
	  </form>
	 </div>
	 
	 <?php
	 $mydb=new mysqli("localhost","root","","search");
	
	 if(isset($_POST["searchb"]))
	 {  
          $search=$_POST['search'];
	    if($search=="")
		{
			echo "<center><b>Sorry!!!...Please Give Me Some Inputs....... </b></center>";
			exit();
		}
	 
	 
	$sql="SELECT * FROM book WHERE id LIKE '$search' OR name LIKE '%$search%' OR author LIKE '%$search%' OR publisher LIKE '%$search%' or description LIKE '%$search%' ";
    $result=$mydb->query($sql);
		
	 
echo "<center><div class='table-responsive'>
<table border='' style='font-weight:bold;margin:20px;' 'class='table-striped' >
<br><tr style='background:gold;'>
<th>Sr. No.</th><th >Book Id</th><th >Book Name</th><th>Author</th><th>Publisher</th><th>Image</th><th>Image</th></tr>";
$a=1;
while($row=$result->fetch_assoc())
{
			echo "<tr><td>".$a."</td><td>".$row['id']."</td><td>".$row['name']."</td><td>".$row['author']."</td><td>".$row['publisher']."</td><td><image src='images/".$row['image']."' class='img-fluid' width='50px' height='auto'></td>
			<td>
			<form action='status1.php' method='post'/>
			<input type='hidden' value='$row[id]' name='id'/>
			<input type='submit' class='btn btn-primary' value='Check Status'/>
			</form>
			</td>
			</tr>";
             $a++;
}
	 }
?>